package ProjetPOO01.Enumerations;

/** Enum�ration des objets achetables
 * @author Xavier CALLOCH
 * Date: 2020-03-18
 *
 */
public enum EAchat {

	Television,
	Telephone,
	Ordinateur,
	Livre,
	Dvd
	
}
