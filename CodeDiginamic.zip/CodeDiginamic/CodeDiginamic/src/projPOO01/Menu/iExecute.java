package projPOO01.Menu;

@FunctionalInterface
public interface iExecute {
	void apply();
}