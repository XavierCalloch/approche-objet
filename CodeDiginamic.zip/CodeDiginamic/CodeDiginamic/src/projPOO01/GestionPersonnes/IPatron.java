package projPOO01.GestionPersonnes;

public interface IPatron {
	public void embauche();
	public void paieSalarie();
	public void licencie();
	
}
